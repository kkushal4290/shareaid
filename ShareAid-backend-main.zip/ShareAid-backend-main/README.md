# ShareAid-backend

<h1>
  Tech stack: 
</h1>
 Share Aid's backend is built using Django, a powerful and flexible Python web framework. It handles data storage, user authentication, and manages the API endpoints for communication with the frontend.

 <h2>
   Local Development
 </h2>
 To start the server locally use 'python manage.py runserver' command in the root directory. All the apis endpoint can be tested with Postman.

 <h2>Deployed link:</h2>
 https://project-madad.vercel.app/

  <h2>Frontend repo: </h2>
https://github.com/Manan-Bhatia/Donation-App-Frontend

